bash extract.bash
